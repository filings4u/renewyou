/**
 * ReNew You Health & Wellness - Modern Responsive Navigation Component Engine
 * Location: assets/js/navigation.js
 */
document.addEventListener('DOMContentLoaded', () => {
    renderNavigation();
});

/**
 * Builds and injects the complete navigation header block into the HTML target
 */
function renderNavigation() {
    const target = document.getElementById('navigation-target');
    if (!target) return;

    target.innerHTML = `
        <!-- Quick Contact Utility Strip -->
        <div class="global-top-bar" style="background-color: var(--purple-primary, #3E0D5F); color: var(--bg-white); padding: 10px 20px; font-size: 0.9rem; font-family: system-ui, -apple-system, sans-serif; box-sizing: border-box; width: 100%;">
            <style>
                /* Mobile responsive rule to remove the top bar */
                @media (max-width: 768px) {
                    .global-top-bar { display: none !important; }
                }
            </style>
            <div style="max-width: 1450px; margin: 0 auto; display: flex; flex-wrap: wrap; justify-content: space-between; gap: 10px; box-sizing: border-box;">
                <span style="display: flex; align-items: center; gap: 6px;">📍 500 Ashland Ave., Suite 101, Chicago Heights, IL 60411</span>
                <div style="display: flex; flex-wrap: wrap; gap: 15px;">
                    <span style="display: flex; align-items: center; gap: 6px;">📞 708-329-2155</span>
                    <span style="display: flex; align-items: center; gap: 6px;">✉️ info@renewyouhealthwellness.com</span>
                </div>
            </div>
        </div>

        <header style="background-color: var(--bg-white); box-shadow: 0 2px 10px rgba(62, 13, 95, 0.05); position: sticky; top: 0; z-index: 1000; width: 100%; box-sizing: border-box;">
            <div class="nav-container" style="max-width: 1450px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; position: relative; box-sizing: border-box;">
                <!-- Logo -->
                <a href="index.html" class="nav-logo" style="display: block;">
                    <img src="images/logo2.png" alt="ReNew You Health & Wellness Logo" style="height: 50px; width: auto; display: block;">
                </a>

                <!-- STRICT UNBREAKABLE HORIZONTAL FLEX TOGGLE RECTANGLE -->
                <button class="menu-toggle" id="mobileMenuBtn" aria-label="Toggle Navigation" style="display: none; align-items: center !important; justify-content: center !important; flex-direction: row !important; gap: 10px !important; background-color: var(--bg-offwhite) !important; border: 1px solid rgba(138, 52, 159, 0.2) !important; border-radius: 6px !important; padding: 6px 14px !important; height: 38px !important; width: auto !important; min-width: 90px !important; max-width: 110px !important; cursor: pointer; box-sizing: border-box !important; overflow: hidden !important;">
                    <span style="font-size: 0.85rem !important; font-weight: 700 !important; color: #ffffff !important; text-transform: uppercase !important; letter-spacing: 1px !important; font-family: system-ui, -apple-system, sans-serif !important; display: inline-block !important; line-height: 1 !important; margin: 0 !important; padding: 0 !important; white-space: nowrap !important;">Menu</span>
                    <div style="display: flex !important; flex-direction: column !important; justify-content: center !important; gap: 3px !important; width: 16px !important; height: 12px !important; min-width: 16px !important; margin: 0 !important; padding: 0 !important; box-sizing: border-box !important;">
                        <span style="display: block !important; width: 100% !important; height: 2px !important; background-color: var(--purple-primary) !important; border-radius: 1px !important;"></span>
                        <span style="display: block !important; width: 100% !important; height: 2px !important; background-color: var(--purple-primary) !important; border-radius: 1px !important;"></span>
                        <span style="display: block !important; width: 100% !important; height: 2px !important; background-color: var(--purple-primary) !important; border-radius: 1px !important;"></span>
                    </div>
                </button>
                <!-- Navigation Links List Menu -->
                <ul class="nav-menu" id="navMenu" style="display: flex; align-items: center; gap: 25px; list-style: none; margin: 0; padding: 0; box-sizing: border-box;">
                    <li><a href="index.html" class="nav-link" data-page="index" style="color: var(--purple-primary); text-decoration: none; font-weight: 600; font-size: 1rem; transition: color 0.3s ease;">Home</a></li>
                    <li><a href="about.html" class="nav-link" data-page="about" style="color: var(--purple-primary); text-decoration: none; font-weight: 600; font-size: 1rem; transition: color 0.3s ease;">About</a></li>
                    <li><a href="services.html" class="nav-link" data-page="services" style="color: var(--purple-primary); text-decoration: none; font-weight: 600; font-size: 1rem; transition: color 0.3s ease;">Services</a></li>

                    <li><a href="insurance.html" class="nav-link" data-page="insurance" style="color: var(--purple-primary); text-decoration: none; font-weight: 600; font-size: 1rem; transition: color 0.3s ease;">Insurance</a></li>
                    <li><a href="patients.html" class="nav-link" data-page="patients" style="color: var(--purple-primary); text-decoration: none; font-weight: 600; font-size: 1rem; transition: color 0.3s ease;">Patients</a></li>
                    <li><a href="payment-plans.html" class="nav-link" data-page="patients" style="color: var(--purple-primary); text-decoration: none; font-weight: 600; font-size: 1rem; transition: color 0.3s ease;">Payment Plans</a></li>
                    <li><a href="contact.html" class="nav-link" data-page="contact" style="color: var(--purple-primary); text-decoration: none; font-weight: 600; font-size: 1rem; transition: color 0.3s ease;">Contact</a></li>

                        <!-- Professional DOT Dropdown Element with Continuous Hover Zone -->
                    <li class="nav-item-dropdown" style="position: relative; display: inline-block; padding-bottom: 15px; margin-bottom: -15px;">
                        <a href="" class="nav-link" style="color: var(--purple-primary); text-decoration: none; font-weight: 600; font-size: 1rem; transition: color 0.3s ease; display: flex; align-items: center; gap: 4px;">
                            DOT Compliance
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
                        </a>
                        <div class="dropdown-menu-wrapper" style="position: absolute; top: 100%; left: 0; padding-top: 10px; display: none; z-index: 1000;">
                            <ul class="dropdown-menu-list" style="background: #ffffff; min-width: 240px; box-shadow: 0 10px 30px rgba(62, 13, 95, 0.08); border-radius: 12px; padding: 10px 0; margin: 0; list-style: none; border: 1px solid rgba(138, 52, 159, 0.06);">
                                <li><a href="dot-drug-tests.html" style="color: #333; padding: 12px 20px; text-decoration: none; display: block; font-size: 0.95rem; font-weight: 500; transition: all 0.2s ease;">Overview & Services</a></li>
                                <li><a href="dot-drivers.html" style="color: #333; padding: 12px 20px; text-decoration: none; display: block; font-size: 0.95rem; font-weight: 500; transition: all 0.2s ease;">Commercial Drivers</a></li>
                                <li><a href="dot-corporate.html" style="color: #333; padding: 12px 20px; text-decoration: none; display: block; font-size: 0.95rem; font-weight: 500; transition: all 0.2s ease;">Corporate Programs</a></li>
                                <li><a href="dot-employers.html" style="color: #333; padding: 12px 20px; text-decoration: none; display: block; font-size: 0.95rem; font-weight: 500; transition: all 0.2s ease;">Employer Programs</a></li>
                                <li><a href="dot-physicals.html" style="color: #333; padding: 12px 20px; text-decoration: none; display: block; font-size: 0.95rem; font-weight: 500; transition: all 0.2s ease;">DOT Physicals</a></li>
                                </li>
                            </ul>
                        </div>
                    </li>


<!-- Reconfigured Navigation Menu Item List Element with Dropdown -->
<li style="margin-left: 5px; position: relative; display: inline-block;" id="navDropdownContainer">
  
  <!-- Main Trigger Button -->
  <button onclick="toggleNavDropdown(event)" class="btn-nav" style="background: linear-gradient(135deg, var(--green-secondary), var(--green-primary)); color: var(--bg-white); padding: 10px 22px; border-radius: 25px; font-weight: 600; font-size: 0.95rem; display: inline-flex; align-items: center; gap: 8px; transition: all 0.3s ease; box-shadow: 0 4px 10px rgba(79, 148, 12, 0.15); border: none; cursor: pointer; font-family: inherit;">
    Book Services <span style="font-size: 0.75rem; transform: rotate(0deg); transition: transform 0.2s;" id="dropdownChevron">▼</span>
  </button>

  <!-- Floating Dropdown Option List Menu Container -->
  <div id="navBookingDropdown" style="display: none; position: absolute; top: 100%; right: 0; margin-top: 8px; background: #ffffff; min-width: 200px; border-radius: 12px; border: 1px solid rgba(138, 52, 159, 0.08); box-shadow: 0 10px 30px rgba(62, 13, 95, 0.08); overflow: hidden; z-index: 999999; box-sizing: border-box;">
    <a href="#" onclick="triggerModalBooking(event)" style="display: block; padding: 12px 20px; font-size: 0.95rem; font-weight: 600; color: var(--purple-primary, #3E0D5F); text-decoration: none; transition: background 0.2s; text-align: left;">
      Book Appointment
    </a>
    <a href="dot-appointment.html" style="display: block; padding: 12px 20px; font-size: 0.95rem; font-weight: 600; color: var(--purple-primary, #3E0D5F); text-decoration: none; border-top: 1px solid #dfe5ec; transition: background 0.2s; text-align: left;">
      Book Drug Test
    </a>
  </div>

  <style>
    /* Premium Hover States for Menu Options Layout */
    #navBookingDropdown a:hover {
      background-color: rgba(138, 52, 159, 0.04) !important;
      color: var(--purple-accent, #8A349B) !important;
    }
  </style>
</li>


<!-- Unified Full-Screen Overlay Modal Container -->
<div id="bookingModalOverlay" style="display: none; position: fixed; inset: 0; background-color: rgba(0, 0, 0, 0.6); z-index: 99999; backdrop-filter: blur(4px); align-items: center; justify-content: center; padding: 20px; box-sizing: border-box;">
  
  <div style="background-color: #ffffff; width: 100%; max-width: 1000px; height: 85vh; border-radius: 20px; overflow: hidden; position: relative; box-shadow: 0 20px 50px rgba(0,0,0,0.3); display: flex; flex-direction: column;">
    
    <!-- Modal Control Header Bar Component -->
    <div style="width: 100%; background: #ffffff; padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; box-sizing: border-box; border-bottom: 1px solid #dfe5ec;">
      <h3 style="margin: 0; color: var(--purple-primary); font-size: 1.2rem; font-weight: 800;">Secure Scheduling Gateway</h3>
      <button onclick="closeBookingModal()" style="background: rgba(138, 52, 159, 0.05); color: var(--purple-primary); border: none; font-size: 1.4rem; line-height: 1; font-weight: bold; width: 36px; height: 36px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: background 0.2s;">
        &times;
      </button>
    </div>

    <!-- Interactive Iframe Content Viewer Engine -->
    <div style="flex: 1; width: 100%; height: 100%; -webkit-overflow-scrolling: touch; overflow-y: auto; background: #ffffff;">
      <iframe id="bookingModalIframe" src="" style="width: 100%; height: 100%; border: none; display: block;" title="Tebra Patient Booking Schedule Portal"></iframe>
    </div>

  </div>
</div>
                </ul>

                

                <style>
                    /* Enhanced hover zones with zero dead structural air space gaps */
                    .nav-item-dropdown:hover .dropdown-menu-wrapper { display: block !important; }
                    .dropdown-menu-list li a:hover { background-color: rgba(138, 52, 159, 0.03); color: var(--purple-primary) !important; }
                </style>
            </div>
        </header>
        <!-- Inject Adaptive Responsive Layout Break Rules -->
        <style>
            @media (max-width: 991px) {
                #mobileMenuBtn { display: inline-flex !important; }
                #navMenu { display: none !important; flex-direction: column !important; align-items: stretch !important; position: absolute !important; top: 100%; right: 20px !important; width: 280px !important; background-color: var(--bg-white) !important; padding: 25px !important; border-radius: 16px !important; border: 1px solid rgba(138, 52, 159, 0.08) !important; box-shadow: 0 15px 40px rgba(62, 13, 95, 0.15) !important; z-index: 999 !important; gap: 16px !important; }
                #navMenu.show-mobile-dropdown { display: flex !important; }
                #navMenu li { width: 100% !important; text-align: left !important; }
                #navMenu .btn-nav { display: block !important; text-align: center !important; margin-top: 5px !important; }
                #mobileMenuBtn:hover { background-color: rgba(138, 52, 159, 0.05) !important; border-color: var(--purple-accent) !important; }
                
                /* Ensure dropdown displays gracefully inside the mobile drawer */
                .nav-item-dropdown { padding-bottom: 0 !important; margin-bottom: 0 !important; }
                .nav-item-dropdown:hover .dropdown-menu-wrapper { position: relative !important; display: block !important; top: 0 !important; padding-top: 5px !important; }
                .dropdown-menu-list { box-shadow: none !important; border: none !important; background: rgba(138, 52, 159, 0.02) !important; padding: 5px 0 !important; }
                .dropdown-menu-list li a { padding: 8px 15px !important; }
            }
        </style>
    `;
    initMobileMenu();
    highlightActiveLink();
}

/**
 * Toggles responsive right-hand floating dropdown menu display visibility rules
 */
function initMobileMenu() {
    const menuToggle = document.getElementById('mobileMenuBtn');
    const navMenu = document.getElementById('navMenu');
    if (!menuToggle || !navMenu) return;

    menuToggle.addEventListener('click', (event) => {
        event.stopPropagation();
        navMenu.classList.toggle('show-mobile-dropdown');
    });

    document.addEventListener('click', (event) => {
        if (!navMenu.contains(event.target) && event.target !== menuToggle) {
            navMenu.classList.remove('show-mobile-dropdown');
        }
    });
}

/**
 * Automatically calculates and tags the active page item matching the URL path
 */
function highlightActiveLink() {
    const path = window.location.pathname;
    const page = path.split("/").pop().replace(".html", "") || "index";
    const activeLink = document.querySelector(`.nav-link[data-page="${page}"]`);
    if (activeLink) {
        activeLink.style.color = "var(--purple-accent)";
    }
}

/**
 * Triggers the deployment layout block and attaches the verified secure patient portal link
 */
function openBookingModal() {
  const overlay = document.getElementById('bookingModalOverlay');
  const iframe = document.getElementById('bookingModalIframe');
  
  if (overlay && iframe) {
    iframe.src = "https://www.tebra.com/care/provider/angela-martin-1962195958";
    overlay.style.display = 'flex';
    document.body.style.overflow = 'hidden'; // Prevents parent background viewport scrolling
  }
}

/**
 * Strips active sources and drops display rules down to prevent hidden background media playback loops
 */
function closeBookingModal() {
  const overlay = document.getElementById('bookingModalOverlay');
  const iframe = document.getElementById('bookingModalIframe');
  
  if (overlay && iframe) {
    overlay.style.display = 'none';
    iframe.src = ""; // Clears allocation states completely
    document.body.style.overflow = 'auto'; // Restores routine document scroll paths
  }
}

// Binds background modal masking dropouts cleanly on direct outer clicks
document.addEventListener('DOMContentLoaded', () => {
  const overlay = document.getElementById('bookingModalOverlay');
  if (overlay) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeBookingModal();
    });
  }
});

/**
 * Toggles visibility rules for the menu tracking drop interface
 */
function toggleNavDropdown(event) {
  event.stopPropagation(); // Prevents instant global document document body click close loops
  const menu = document.getElementById('navBookingDropdown');
  const chevron = document.getElementById('dropdownChevron');
  
  if (menu && chevron) {
    const isHidden = menu.style.display === 'none' || menu.style.display === '';
    menu.style.display = isHidden ? 'block' : 'none';
    chevron.style.transform = isHidden ? 'rotate(180deg)' : 'rotate(0deg)';
  }
}

/**
 * Intercepts links safely to load the pop up layout target context directly
 */
function triggerModalBooking(event) {
  event.preventDefault();
  closeNavDropdown();
  if (typeof openBookingModal === 'function') {
    openBookingModal();
  }
}

/**
 * Hard reset dropdown structural classes down to original closed base configurations
 */
function closeNavDropdown() {
  const menu = document.getElementById('navBookingDropdown');
  const chevron = document.getElementById('dropdownChevron');
  if (menu && chevron) {
    menu.style.display = 'none';
    chevron.style.transform = 'rotate(0deg)';
  }
}

// Binds clean window click captures to drop visibility states if clicking outside the menu element box area
document.addEventListener('click', (e) => {
  const container = document.getElementById('navDropdownContainer');
  if (container && !container.contains(e.target)) {
    closeNavDropdown();
  }
});
